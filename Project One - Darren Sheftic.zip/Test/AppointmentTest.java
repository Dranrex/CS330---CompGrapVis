package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.util.Date;

import Appointment.Appointment;

// The following JUnit 5 Tests use the Arrange-Act-Assert pattern use by Behavior-Driven Development. 
// Arrange sets up the task.
// Act targets the desired behavior of the task.
// Assert verifies the success or failure of the response of the test.

public class AppointmentTest {

    @Test
    @DisplayName("Test valid appointment creation")
    void testValidAppointmentCreation() {
        // Arrange
        String appointmentID = "A123456789";
        Date appointmentDate = new Date(System.currentTimeMillis() + 86400000); // Future date
        String description = "Valid Description";

        // Act
        Appointment appointment = new Appointment(appointmentID, appointmentDate, description);

        // Assert
        assertNotNull(appointment);
        assertEquals(appointmentID, appointment.getAppointmentID());
        assertEquals(appointmentDate, appointment.getAppointmentDate());
        assertEquals(description, appointment.getDescription());
    }

    
    @Test
    @DisplayName("Test invalid appointment ID (null)")
    void testInvalidAppointmentIDNull() {
        // Arrange
        String appointmentID = null;
        Date appointmentDate = new Date(System.currentTimeMillis() + 86400000); // Future date
        String description = "Valid Description";

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> new Appointment(appointmentID, appointmentDate, description));
    }

    @Test
    @DisplayName("Test invalid appointment ID (too long)")
    void testInvalidAppointmentIDTooLong() {
        // Arrange
        String appointmentID = "A12345678901"; // More than 10 characters
        Date appointmentDate = new Date(System.currentTimeMillis() + 86400000); // Future date
        String description = "Valid Description";

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> new Appointment(appointmentID, appointmentDate, description));
    }

    @Test
    @DisplayName("Test invalid appointment date (past date)")
    void testInvalidAppointmentDatePast() {
        // Arrange
        String appointmentID = "A123456789";
        Date appointmentDate = new Date(System.currentTimeMillis() - 86400000); // Past date
        String description = "Valid Description";

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> new Appointment(appointmentID, appointmentDate, description));
    }

    @Test
    @DisplayName("Test invalid description (null)")
    void testInvalidDescriptionNull() {
        // Arrange
        String appointmentID = "A123456789";
        Date appointmentDate = new Date(System.currentTimeMillis() + 86400000); // Future date
        String description = null;

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> new Appointment(appointmentID, appointmentDate, description));
    }

    @Test
    @DisplayName("Test invalid description (too long)")
    void testInvalidDescriptionTooLong() {
        // Arrange
        String appointmentID = "A123456789";
        Date appointmentDate = new Date(System.currentTimeMillis() + 86400000); // Future date
        String description = "This description is longer than fifty characters and should fail.";

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> new Appointment(appointmentID, appointmentDate, description));
    }
}
