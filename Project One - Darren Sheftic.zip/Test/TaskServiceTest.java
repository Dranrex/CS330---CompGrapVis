package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import Task.TaskService;

// The following JUnit 5 Tests use the Arrange-Act-Assert pattern use by Behavior-Driven Development. 
// Arrange sets up the task.
// Act targets the desired behavior of the task.
// Assert verifies the success or failure of the response of the test.

public class TaskServiceTest {
    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    @AfterEach
    void tearDown() {
        service = null; // Ensures clean state after each test
    }

    @Test
    @DisplayName("Test to Add Task")
    void testAddTask() {
        // Act
        service.addTask("Task1", "Name1", "Description1");

        // Assert
        assertNotNull(service.getTask("Task1"), "Task was not added.");
    }

    @Test
    @DisplayName("Test to Delete Task")
    void testDeleteTask() {
        // Arrange
        service.addTask("Task1", "Name1", "Description1");

        // Act
        service.deleteTask("Task1");

        // Assert
        assertNull(service.getTask("Task1"), "Task was not deleted.");
    }

    @Test
    @DisplayName("Test to Update Task Name")
    void testUpdateTaskName() {
        // Arrange
        service.addTask("Task1", "Name1", "Description1");

        // Act
        service.updateName("Task1", "NewName");

        // Assert
        assertEquals("NewName", service.getTask("Task1").getName(), "Task name was not updated.");
    }


    @Test
    @DisplayName("Test to Update Task Description")
    void testUpdateTaskDescription() {
        // Arrange
        service.addTask("Task1", "Name1", "Description1");

        // Act
        service.updateDescription("Task1", "NewDescription");

        // Assert
        assertEquals("NewDescription", service.getTask("Task1").getDescription(), "Task description was not updated.");
    }


    @Test
    @DisplayName("Test to Ensure Task ID is Unique")
    void testUniqueTaskID() {
        // Arrange
        service.addTask("Task1", "Name1", "Description1");

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> service.addTask("Task1", "Name2", "Description2"));
    }

    @Test
    @DisplayName("Test to Ensure Task ID Exists")
    void testTaskIDExists() {
        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> service.updateName("NewName", "NonExistentTask"));
    }
}
