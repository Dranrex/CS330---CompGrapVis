package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import Task.Task;

import org.junit.jupiter.api.DisplayName;

// The following JUnit 5 Tests use the Arrange-Act-Assert pattern use by Behavior-Driven Development. 
// Arrange sets up the task.
// Act targets the desired behavior of the task.
// Assert verifies the success or failure of the response of the test.

public class TaskTest {

    @Test
    @DisplayName("Task ID cannot have more than 10 characters")
    void testTaskIDWithMoreThanTenCharacters() {
        // Ensure an IllegalArgumentException is thrown when task ID has more than 10 characters
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "ValidName", "ValidDescription"));
    }

    @Test
    @DisplayName("Task name cannot have more than 20 characters")
    void testTaskNameWithMoreThanTwentyCharacters() {
        // Ensure an IllegalArgumentException is thrown when task name has more than 20 characters
        assertThrows(IllegalArgumentException.class, () -> new Task("ValidID", "123456789012345678901", "ValidDescription"));
    }

    @Test
    @DisplayName("Task description cannot have more than 50 characters")
    void testTaskDescriptionWithMoreThanFiftyCharacters() {
        // Ensure an IllegalArgumentException is thrown when task description has more than 50 characters
        assertThrows(IllegalArgumentException.class, () -> new Task("ValidID", "ValidName", "123456789012345678901234567890123456789012345678901"));
    }

    @Test
    @DisplayName("Task ID shall not be null")
    void testTaskIDNotNull() {
        // Ensure an IllegalArgumentException is thrown when task ID is null
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "ValidName", "ValidDescription"));
    }

    @Test
    @DisplayName("Task name shall not be null")
    void testTaskNameNotNull() {
        // Ensure an IllegalArgumentException is thrown when task name is null
        assertThrows(IllegalArgumentException.class, () -> new Task("ValidID", null, "ValidDescription"));
    }

    @Test
    @DisplayName("Task description shall not be null")
    void testTaskDescriptionNotNull() {
        // Ensure an IllegalArgumentException is thrown when task description is null
        assertThrows(IllegalArgumentException.class, () -> new Task("ValidID", "ValidName", null));
    }

    @Test
    @DisplayName("Task object with valid attributes")
    void testValidTaskObject() {
        // Arrange
        String taskID = "ValidID";
        String name = "ValidName";
        String description = "ValidDescription";

        // Act
        Task task = new Task(taskID, name, description);

        // Assert
        assertNotNull(task);
        assertEquals(taskID, task.getTaskID());
        assertEquals(name, task.getName());
        assertEquals(description, task.getDescription());
    }
}
