package Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.util.Date;
import Appointment.AppointmentService;

// The following JUnit 5 Tests use the Arrange-Act-Assert pattern use by Behavior-Driven Development. 
// Arrange sets up the task.
// Act targets the desired behavior of the task.
// Assert verifies the success or failure of the response of the test.

public class AppointmentServiceTest {
    private AppointmentService service;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
    }

    @AfterEach
    void tearDown() {
        service = null; // Ensures clean state after each test
    }

    @Test
    @DisplayName("Test to Add Appointment")
    void testAddAppointment() {
        // Act
        Date appointmentDate = new Date(System.currentTimeMillis() + 86400000); // Future date
        service.addAppointment("A123456789", appointmentDate, "Valid Description");

        // Assert
        assertNotNull(service.getAppointment("A123456789"), "Appointment was not added.");
    }
    @Test
    @DisplayName("Test to Add Appointment with Past Date")
    void testAddAppointmentWithPastDate() {
        // Arrange
        Date pastDate = new Date(System.currentTimeMillis() - 86400000); // Past date

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment("A987654321", pastDate, "Invalid Description"));
    }

    @Test
    @DisplayName("Test to Delete Appointment")
    void testDeleteAppointment() {
        // Arrange
        Date appointmentDate = new Date(System.currentTimeMillis() + 86400000); // Future date
        service.addAppointment("A123456789", appointmentDate, "Valid Description");

        // Act
        service.deleteAppointment("A123456789");

        // Assert
        assertNull(service.getAppointment("A123456789"), "Appointment was not deleted.");
    }

    @Test
    @DisplayName("Test to Ensure Appointment ID is Unique")
    void testUniqueAppointmentID() {
        // Arrange
        Date appointmentDate1 = new Date(System.currentTimeMillis() + 86400000); // Future date
        Date appointmentDate2 = new Date(System.currentTimeMillis() + 86400000); // Future date
        service.addAppointment("A123456789", appointmentDate1, "Valid Description");

        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment("A123456789", appointmentDate2, "Valid Description"));
    }

    @Test
    @DisplayName("Test to Ensure Appointment ID Exists")
    void testAppointmentIDExists() {
        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("NonExistentAppointment", "New Description"));
    }
}
