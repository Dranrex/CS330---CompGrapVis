/*
 * Name: 	Darren Sheftic 
 * Course: 	CS320 
 * Date: 	February 4, 2024
 * Description: This is the appointment service class.
 * Note: Use java.util.Date for the appointmentDate field and use before(new Date()) to check if the date is in the past.

*/

package Appointment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AppointmentService {
    private final List<Appointment> appointmentList = new ArrayList<>();

//    Not needed unless testing for display output of Appointment methods
//    public void displayAppointmentList() {
//        for (Appointment appointment : appointmentList) {
//            System.out.println("Appointment ID: " + appointment.getAppointmentID());
//            System.out.println("Appointment Date: " + appointment.getAppointmentDate());
//            System.out.println("Description: " + appointment.getDescription() + "\n");
//        }
//    }

    public void addAppointment(String appointmentID, Date appointmentDate, String description) {
        if (appointmentID == null || appointmentDate == null || description == null) {
            throw new IllegalArgumentException("Appointment ID, Date, or Description cannot be null.");
        }

        if (getAppointment(appointmentID) != null) {
            throw new IllegalArgumentException("Appointment ID: " + appointmentID + " already exists.");
        }

        Appointment appointment = new Appointment(appointmentID, appointmentDate, description);
        appointmentList.add(appointment);
    }

    public Appointment getAppointment(String appointmentID) {
        for (Appointment appointment : appointmentList) {
            if (appointment.getAppointmentID().equals(appointmentID)) {
                return appointment;
            }
        }
        return null; // Return null if appointment not found
    }

    public void deleteAppointment(String appointmentID) {
        Appointment appointmentToRemove = getAppointment(appointmentID);
        if (appointmentToRemove != null) {
            appointmentList.remove(appointmentToRemove);
        } else {
            throw new IllegalArgumentException("Appointment ID: " + appointmentID + " not found.");
        }
    }

    public void updateDescription(String appointmentID, String updatedDescription) {
        Appointment appointmentToUpdate = getAppointment(appointmentID);
        if (appointmentToUpdate != null) {
            appointmentToUpdate.setDescription(updatedDescription);
        } else {
            throw new IllegalArgumentException("Appointment ID: " + appointmentID + " not found.");
        }
    }
}
