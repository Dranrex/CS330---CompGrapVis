/*
 * Name: 	Darren Sheftic 
 * Course: 	CS320 
 * Date: 	February 4, 2024
 * Description: This is the appointment class.
 * Note: Use java.util.Date for the appointmentDate field and use before(new Date()) to check if the date is in the past.
*/

package Appointment;

import java.util.Date;

public class Appointment {
    private final String appointmentID;
    private Date appointmentDate;
    private String description;
	/*
	 * The constructor takes appointmentID, date,  and description as
	 * parameters. Generates a new ID for the appointmentID
	 * field.
	 */
    public Appointment(String appointmentID, Date appointmentDate, String description) {
        if (appointmentID == null || appointmentID.isEmpty() || appointmentID.length() > 10) {
            throw new IllegalArgumentException("Appointment ID is invalid");
        }
        this.appointmentID = appointmentID;

        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment Date is invalid");
        }
        this.appointmentDate = appointmentDate;

        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description is invalid");
        }
        this.description = description;
    }

    public String getAppointmentID() {
        return appointmentID;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment Date is invalid");
        }
        this.appointmentDate = appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description is invalid");
        }
        this.description = description;
    }
}
