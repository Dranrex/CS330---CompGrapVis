/*
 * Name: 	Darren Sheftic 
 * Course: 	CS320 
 * Date: 	February 4, 2024
 * Description: This is the task class.
*/

package Task;

public class Task {
    private final String taskID;
    private String name;
    private String description;
	/*
	 * The constructor takes taskID, name,  and description as
	 * parameters. Generates a new ID for the taskID
	 * field.
	 */
    public Task(String taskID, String name, String description) {
        if (taskID == null || taskID.isEmpty() || taskID.length() > 10) {
            throw new IllegalArgumentException("Task ID is invalid");
        }
        this.taskID = taskID;

        if (name == null || name.isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Name is invalid");
        }
        this.name = name;

        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description is invalid");
        }
        this.description = description;
    }
    // Get TaskID
    public String getTaskID() {
        return taskID;
    }
    // Get Task Name
    public String getName() {
        return name;
    }
    // Set Task Name, cannot be null, empty, or longer than 20 characters.
    public void setName(String name) {
        if (name == null || name.isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Name is invalid");
        }
        this.name = name;
    }
    // Get Description
    public String getDescription() {
        return description;
    }
    // Set Description, cannot be null, empty, or longer than 50 characters.
    public void setDescription(String description) {
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description is invalid");
        }
        this.description = description;
    }
}
