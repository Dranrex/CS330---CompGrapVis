/*
 * Name: 	Darren Sheftic 
 * Course: 	CS320 
 * Date: 	February 4, 2024
 * Description: This is the task service class.
*/

package Task;

import java.util.ArrayList;
import java.util.List;

public class TaskService {
    private final List<Task> taskList = new ArrayList<>();

    /* Task ID: ID#
     * Name: Name
     * Description: Description
     */
    public void displayTaskList() {
        for (Task task : taskList) {
            System.out.println("Task ID: " + task.getTaskID());
            System.out.println("Name: " + task.getName());
            System.out.println("Description: " + task.getDescription() + "\n");
        }
    }
    // Adds task
    public void addTask(String taskID, String name, String description) {
        if (taskID == null || name == null || description == null) {
            throw new IllegalArgumentException("Task ID, name, or description cannot be null.");
        }

        if (getTask(taskID) != null) {
            throw new IllegalArgumentException("Task ID: " + taskID + " already exists.");
        }

        Task task = new Task(taskID, name, description);
        taskList.add(task);
    }
    // Gets task
    public Task getTask(String taskID) {
        for (Task task : taskList) {
            if (task.getTaskID().equals(taskID)) {
                return task;
            }
        }
        return null; // Return null if task not found
    }
    // Deletes task
    public void deleteTask(String taskID) {
        Task taskToRemove = getTask(taskID);
        if (taskToRemove != null) {
            taskList.remove(taskToRemove);
        } else {
            throw new IllegalArgumentException("Task ID: " + taskID + " not found.");
        }
    }
    // Updates Name of task
    public void updateName(String taskID, String updatedName) {
        Task taskToUpdate = getTask(taskID);
        if (taskToUpdate != null) {
            taskToUpdate.setName(updatedName);
        } else {
            throw new IllegalArgumentException("Task ID: " + taskID + " not found.");
        }
    }
    //Updates task description
    public void updateDescription(String taskID, String updatedDescription) {
        Task taskToUpdate = getTask(taskID);
        if (taskToUpdate != null) {
            taskToUpdate.setDescription(updatedDescription);
        } else {
            throw new IllegalArgumentException("Task ID: " + taskID + " not found.");
        }
    }
}
